<?php

$user = $_POST['username'];
$con = mysqli_connect("localhost","root","","bus_pass");


$sql = "SELECT * FROM (SELECT * FROM $user ORDER BY id DESC 
) sub
where pass_status=1";

$result = $con->query($sql);

$rs = mysqli_fetch_assoc($result);

$string = $rs['username'].",".$rs['route'].",".$rs['validity'];

echo $string;

?>