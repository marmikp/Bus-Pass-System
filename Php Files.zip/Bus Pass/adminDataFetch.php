<?php

$con = mysqli_connect("localhost","root","","bus_pass");

$sql1 = "SELECT username from bus_student_login where current_req=1";

$result = mysqli_query($con,$sql1);
$json = "";

while($rs = $result->fetch_assoc()){
	$sql1= "SELECT max(id) FROM ".$rs['username'];
	$result1 = mysqli_query($con,$sql1);
	$count = mysqli_num_rows($result1);
	if ($count==1) {
		$idAI = mysqli_fetch_array($result1);

		
		$sql2 = "SELECT username FROM ".$rs['username']." WHERE id=".$idAI[0]." and co_status=1 and ad_status=0 and pass_status=0";
		$result2 = mysqli_query($con,$sql2);
		
			# code...
			$idAI2 = mysqli_fetch_array($result2);
			if ($json != "") {$json .= ",";}
		    $json .= ''  . $idAI2["username"]  . '';
		
	}

}

echo $json;
?>