<?php

$con = mysqli_connect("localhost","root","","bus_pass");
$taluka = $_POST['string'];
$sqlID = "SELECT max(id) FROM mehsana_dist";
$result_sqlID = mysqli_query($con,$sqlID);
$idMeh = mysqli_fetch_array($result_sqlID);
$sql = "SELECT $taluka FROM mehsana_dist";
$result = mysqli_query($con,$sql);
$outp="";


$row=array ();
while($rs = $result->fetch_assoc()) {
    if ($outp != "") {$outp .= ",";}
    $outp .= ''  . $rs["$taluka"]  . '';
    
}

echo $outp;

?>