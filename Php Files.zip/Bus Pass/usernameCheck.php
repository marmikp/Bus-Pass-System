<?php

$con = mysqli_connect("localhost","root","","bus_pass");
$username = $_POST['user'];

$sql = "SELECT * FROM bus_student_login WHERE username = '$username'";
$result = mysqli_query($con,$sql);

      
      $count = mysqli_num_rows($result);

if ($count > 0) {

	echo "false";
	# code...
}
else{
	echo "true";
}

?>