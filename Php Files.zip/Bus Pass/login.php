<?php

$con = mysqli_connect("localhost","root","","bus_pass");
$username = $_POST['user'];
$password = $_POST['pass'];

$sql = "SELECT * FROM bus_student_login WHERE username = '$username' and password = '$password'";
$result = mysqli_query($con,$sql);

      
      $count = mysqli_num_rows($result);
      
      // If result matched $myusername and $mypassword, table row must be 1 row
		
if($count == 1) {
   echo "true";
}else{echo "false";}

?>