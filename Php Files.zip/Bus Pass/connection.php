<?php

	$server = "127.0.0.1";
	$username = "root";
	$password = "";
	$db = "bus_pass";

	$con = mysqli_connect($server , $username, $password, $db);

?>