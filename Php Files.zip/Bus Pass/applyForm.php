<?php

$con = mysqli_connect("localhost","root","","bus_pass");

$string = $_POST['query'];
$string1 = $_POST['query1'];
$con->query($string);
$con->query($string1);
echo "done";
?>