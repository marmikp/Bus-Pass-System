<?php

$con = mysqli_connect("localhost","root","","bus_pass");

$string = $_POST['student'];

$result = $con->query("SELECT MAX(id) FROM $string");

$rs = mysqli_fetch_array($result);

$sql = "UPDATE $string SET `co_status`='1' WHERE id=".$rs[0];
$con->query($sql);
echo "done";

?>