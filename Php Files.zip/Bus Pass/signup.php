<?php

$con = mysqli_connect("localhost","root","","bus_pass");
$username = $_POST['user'];
$password = $_POST['pass'];
$col_id = $_POST['col_id'];

$sql = "INSERT INTO bus_student_login(`col_id`,`username`,`password`,`current_req`) VALUES ($col_id,'$username','$password',0)";

$sql1 = "CREATE TABLE $username (id int AUTO_INCREMENT,username varchar(20),route varchar(50),validity varchar(50),co_status int,ad_status int,distance int,pass_status int DEFAULT 0,PRIMARY KEY (id))";


$result = mysqli_query($con,$sql);
$result1 = mysqli_query($con,$sql1);

echo "true";

?>