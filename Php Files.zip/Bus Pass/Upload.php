

<?php
  
    $file_path = "upload/";
    $tmp = $_FILES['uploaded_file']['tmp_name'];
    $filename=$_FILES['uploaded_file']['name'];
    $user = $_POST['user'];
    $con = mysqli_connect("localhost","root","","bus_pass");

    $sql = "UPDATE `bus_student_login` SET `image`='$filename' WHERE username='$user'";
    echo $sql;
    $result = mysqli_query($con,$sql);
     
     echo "true";
    $file_path = $file_path . basename( $_FILES['uploaded_file']['name']);
    if(move_uploaded_file($tmp, $file_path) ){
        
        echo "success";
    } else{
        echo "fail";
    }
    
 ?>
