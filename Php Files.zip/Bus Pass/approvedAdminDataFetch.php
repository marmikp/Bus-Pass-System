<?php

$con = mysqli_connect("localhost","root","","bus_pass");
$student = $_POST['student'];
$sql = "SELECT * FROM $student WHERE id = (SELECT MAX(id) FROM $student)";
$result = mysqli_query($con,$sql);
$outp="";

$idAI = mysqli_fetch_array($result);

echo $idAI[0].",".$idAI[1].",".$idAI[2].",".$idAI[3].",".$idAI[4].",".$idAI[5].",".$idAI[6].",".$idAI[7];



?>